// CommonJS (CJS) formatına dəyişdirildi. Bu, "Unexpected keyword or identifier" xətasını həll edir.
const express = require('express');
const path = require('path');
const cors = require('cors'); 
const axios = require('axios'); 
const puppeteer = require('puppeteer');
const bcrypt = require('bcryptjs'); 
const jwt = require('jsonwebtoken');

// __dirname artıq CJS-də avtomatik mövcuddur.

const app = express();

// Konfiqurasiya
// ⚠️ PORT 3000 ilə qarşılaşdığınız EADDRINUSE xətasını aradan qaldırmaq üçün 3001-ə dəyişdirildi.
const PORT = 3001; 
const SECRET_KEY = 'YOUR_SUPER_SECRET_KEY_FOR_JWT'; // Təhlükəsizlik üçün bunu dəyişin!

// Statik faylların düzgün xidməti
// Əgər sizdə 'public' qovluğu varsa, bu faylları təqdim edəcək.
app.use(express.static(path.join(__dirname, 'public')));

app.use(cors());
app.use(express.json());

// 🔐 İstifadəçi yaddaşı (test üçün RAM-da)
const users = new Map();

// ✅ Token doğrulama middleware
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    // Token formatı: "Bearer <token>"
    const token = authHeader?.split(' ')[1]; 
    if (!token) {
        return res.status(401).json({ error: 'Giriş yoxdur. Token tələb olunur.' });
    }

    jwt.verify(token, SECRET_KEY, (err, user) => {
        if (err) {
            // Token etibarsızdır
            return res.status(403).json({ error: 'Etibarsız Token.' });
        }
        req.user = user;
        next();
    });
}

// ✅ Abunəlik yoxlaması middleware
function checkSubscription(req, res, next) {
    const user = users.get(req.user.email);
    // Əgər istifadəçi Map-də yoxdursa və ya abunəliyi false-dursa
    if (!user || !user.subscribed) {
        return res.status(403).json({ error: '🚫 Xidmətə giriş üçün premium abunəlik tələb olunur.' });
    }
    next();
}

// --- Auth Endpoints ---

// 1. Qeydiyyat
app.post('/register', async (req, res) => {
    const { email, password } = req.body;
    if (users.has(email)) {
        // 409 Conflict: Test skriptinin düzgün işləməsi üçün vacibdir
        return res.status(409).json({ error: '❌ Bu email artıq qeydiyyatdan keçib' });
    }
    const hashed = await bcrypt.hash(password, 10);
    // Yeni qeydiyyatdan keçən istifadəçi (abunəlik false)
    users.set(email, { email, password: hashed, subscribed: false });
    console.log(`✅ Yeni istifadəçi qeydiyyatdan keçdi: ${email}`);
    res.json({ message: '✅ Qeydiyyat tamamlandı' });
});

// 2. Giriş
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = users.get(email);
    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.status(401).json({ error: '❌ Yanlış email və ya şifrə' });
    }
    // Token yaradırıq. (Abunəlik statusu yoxdur, middleware daxili yaddaşa müraciət edir)
    const token = jwt.sign({ email: user.email }, SECRET_KEY, { expiresIn: '1h' });
    console.log(`🔐 İstifadəçi giriş etdi: ${email}`);
    res.json({ token });
});

// 3. Abunəlik Aktivləşdirmə
app.post('/subscribe', authenticateToken, (req, res) => {
    const user = users.get(req.user.email);
    if (user) {
        user.subscribed = true;
        users.set(req.user.email, user);
        console.log(`💳 Abunəlik aktivləşdirildi: ${req.user.email}`);
        res.json({ message: '✅ Abunəlik aktivləşdirildi' });
    } else {
        res.status(404).json({ error: 'İstifadəçi tapılmadı' });
    }
});
// --- Auth Endpoints sonu ---

// --- Köməkçi Funksiyalar ---

/**
 * Saniyələri HH:MM:SS formatına çevirir.
 */
function formatDuration(seconds) {
    if (typeof seconds !== 'number' || seconds <= 0) return 'N/A';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    
    const parts = [];
    if (h > 0) parts.push(h);
    parts.push(m.toString().padStart(h > 0 ? 2 : 1, '0'));
    parts.push(s.toString().padStart(2, '0'));

    return parts.join(':');
}

/**
 * MOCK (Simulyasiya): 30 saniyə ilə 10 dəqiqə arasında təsadüfi bir müddət qaytarır.
 */
async function getYouTubeDuration(videoId) {
    // Təsadüfi müddət simulyasiyası
    const randomSeconds = Math.floor(Math.random() * (600 - 30 + 1)) + 30;
    return randomSeconds;
}


/**
 * Şəkilin təxmini ölçüsünü (Content-Length) MB ilə qaytarır.
 */
async function getImageSize(imageUrl) {
    if (!imageUrl) return 'Məlumat yoxdur';
    try {
        // Sadəcə header-ləri çəkirik ki, tam şəkli yükləməyək
        const response = await axios.head(imageUrl, { timeout: 3000 }); 
        const size = response.headers['content-length'];
        if (size) {
            const sizeMB = (parseInt(size, 10) / (1024 * 1024)).toFixed(2);
            return `${sizeMB} MB`;
        }
    } catch (error) {
        // Konsol xəbərdarlığı Azərbaycan dilindədir
        console.warn(`[Ölçü Xətası]: Şəkil ölçüsü tapıla bilmədi: ${error.message}`);
    }
    return 'Təxmini ölçü tapılmadı';
}

/**
 * Ümumi URL-dən Oembed məlumatlarını çıxarmağa çalışır (Vimeo daxil olmaqla).
 */
async function extractOembedData(url) {
    try {
        // 1. Oembed linkini tapmaq üçün səhifənin HTML-ini çəkin
        const pageResponse = await axios.get(url, { timeout: 10000 });
        const html = pageResponse.data;

        // RegEx ilə oEmbed linkini axtarırıq
        const oembedMatch = html.match(/<link\s+(?:[^>]*?)rel=["']alternate["']\s+(?:[^>]*?)type=["']application\/json\+oembed["']\s+(?:[^>]*?)href=["'](.*?)"/i);
        
        let oembedUrl = null;

        if (oembedMatch && oembedMatch[1]) {
            oembedUrl = oembedMatch[1].replace(/&amp;/g, '&');
        } else if (url.includes('vimeo.com/')) {
            // Vimeo üçün xüsusi oEmbed endpoint
            oembedUrl = `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(url)}`;
        }
        
        if (oembedUrl) {
            // 3. Oembed məlumatını çəkin
            const oembedResponse = await axios.get(oembedUrl, { timeout: 5000 });
            const data = oembedResponse.data;

            console.log(`[Oembed Uğurlu]: Məlumat ${oembedUrl} vasitəsilə alındı.`);

            const durationFormatted = data.duration ? formatDuration(data.duration) : 'N/A';

            return {
                thumbnail: data.thumbnail_url || null,
                title: data.title || 'Oembed Başlıq',
                // Təsvir üçün müəllif adını, yoxsa başqa bir təsviri istifadə edirik
                description: data.author_name ? `Müəllif: ${data.author_name}` : data.html || 'Təsvir tapılmadı',
                duration: durationFormatted, // Formatlanmış müddət
                date: 'N/A',
                embedHtml: data.html || null 
            };
        }

        return null; // Oembed linki tapılmadı

    } catch (error) {
        // Konsol xəbərdarlığı Azərbaycan dilindədir
        console.warn(`[Oembed Ümumi XƏTASI URL ${url}]: ${error.message}. Puppeteer-ə keçilir.`);
        return null;
    }
}

// --- YouTube Məlumatının Çıxarılması ---

async function extractYouTubeData(url) {
    const match = url.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/);
    if (!match) return { thumbnail: null, title: 'YouTube Video', description: 'Məlumat tapılmadı', duration: 'N/A', date: 'N/A', embedHtml: null };
    
    const videoId = match[1];
    // Yüksək keyfiyyətli thumbnail linki
    const thumbnail = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`; 
    
    // MÜDDƏTİ VƏ TARİXİ API KEY OLMADIĞINDAN MOCK EDİRİK/İQNORE EDİRİK
    const durationSeconds = await getYouTubeDuration(videoId);
    const durationFormatted = formatDuration(durationSeconds);

    try {
        // YouTube Oembed müraciəti (Başlıq, Müəllif, Embed HTML üçün)
        const oembedUrl = `https://www.youtube.com/oembed?url=${url}&format=json`;
        const response = await axios.get(oembedUrl, { timeout: 5000 });
        const data = response.data;
        
        return {
            thumbnail: thumbnail, // Yüksək keyfiyyətli thumbnail
            title: data.title || 'YouTube Video',
            // DƏYİŞİKLİK: Təsvir olaraq xidmət adını və kanal adını göstəririk.
            description: data.author_name && data.provider_name
                ? `${data.provider_name} kanalı: ${data.author_name}` 
                : (data.author_name ? `Kanal: ${data.author_name}` : 'Təsvir tapılmadı'),
            duration: durationFormatted, // Mock müddət
            date: 'N/A', // Tarix (Real API Key yoxdur)
            embedHtml: data.html || null // Embed HTML
        };
    } catch (error) {
        // Konsol xəbərdarlığı Azərbaycan dilindədir
        console.warn(`[YouTube OEmbed XƏTASI]: ${error.message}. Yalnız thumbnail və mock müddət qaytarılır.`);
        return { 
            thumbnail: thumbnail, 
            title: 'YouTube Video', 
            description: 'Təsvir tapılmadı', 
            duration: durationFormatted, 
            date: 'N/A', 
            embedHtml: null 
        };
    }
}


// --- TikTok Məlumatının Çıxarılması ---

async function extractTikTokData(url) {
    const match = url.match(/tiktok\.com\/@[\w.]+\/video\/(\d+)/);
    if (!match) return null;

    try {
        // TikTok Oembed müraciəti
        const response = await axios.get(`https://www.tiktok.com/oembed?url=${url}`);
        const data = response.data;
        return {
            thumbnail: data.thumbnail_url || null,
            title: data.title || 'TikTok Video',
            description: data.author_name ? `İstifadəçi: ${data.author_name}` : 'Təsvir tapılmadı',
            duration: 'N/A', // TikTok müddəti oEmbed-də yoxdur
            date: 'N/A',
            embedHtml: data.html || null 
        };
    } catch (error) {
        // Konsol xəbərdarlığı Azərbaycan dilindədir
        console.warn(`[TikTok OEmbed XƏTASI]: ${error.message}. Generic çıxarma işləyəcək.`);
        return null; 
    }
}

// --- Ümumi Səhifələrdən Məlumat Çıxarılması (Puppeteer) ---

async function extractGenericData(url) {
    let browser;
    let result = {
        thumbnail: null,
        title: 'Başlıq tapılmadı',
        description: 'Təsvir tapılmadı',
        duration: 'N/A',
        date: 'N/A',
        embedHtml: null,
    };
    
    try {
        // Puppeteer konfiqurasiyası
        browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox', 
                '--disable-setuid-sandbox',
                '--disable-gpu',
                '--disable-dev-shm-usage',
                '--no-zygote'
            ],
            executablePath: puppeteer.executablePath(),
        });

        const page = await browser.newPage();
        
        await page.goto(url, {
            waitUntil: 'networkidle0', 
            timeout: 20000 
        });

        const data = await page.evaluate(() => {
            // Open Graph (og:) və Twitter Cards (twitter:) meta taglarını axtarır
            const ogImage = document.querySelector('meta[property="og:image"]')?.content;
            const ogTitle = document.querySelector('meta[property="og:title"]')?.content;
            const ogDesc = document.querySelector('meta[property="og:description"]')?.content;
            const twitterImage = document.querySelector('meta[name="twitter:image"]')?.content;
            const pageTitle = document.title;
            
            // Səhifədəki ən böyük şəkillərdən birini tapır
            const largestImg = Array.from(document.querySelectorAll('img'))
                .sort((a, b) => (b.offsetWidth * b.offsetHeight) - (a.offsetWidth * b.offsetHeight))
                .find(img => (img.offsetWidth * img.offsetHeight) > 10000); 

            return {
                thumbnail: ogImage || twitterImage || largestImg?.src || null,
                title: ogTitle || pageTitle || 'Başlıq tapılmadı',
                description: ogDesc || 'Təsvir tapılmadı'
            };
        });
        
        result.thumbnail = data.thumbnail || 'https://via.placeholder.com/640x360?text=No+Thumbnail+Found';
        result.title = data.title;
        result.description = data.description;
        
        return result;

    } catch (error) {
        // Konsol xəbərdarlığı Azərbaycan dilindədir
        console.error(`❌ Puppeteer xətası URL ${url}: ${error.message}. Brauzer başlaya bilmədi və ya vaxt bitdi.`);
        result.thumbnail = 'https://via.placeholder.com/640x360?text=Error+Loading+Page'; 
        return result;
    } finally {
        if (browser) { 
            // Qısa müddətdə işləyib bitirmək üçün brauzeri bağlayırıq
            await browser.close();
        }
    }
}


// 🔗 ƏSAS API Endpoint (abunəliklə qorunur)
app.post('/api/thumbnail', authenticateToken, checkSubscription, async (req, res) => {
    const { url } = req.body;
    if (!url) {
        return res.status(400).json({ error: 'URL sahəsi tələb olunur.' });
    }

    console.log('🔗 Gələn URL:', url);

    try {
        let data = {};
        let isVideo = false;
        let success = false;

        // 1. YouTube yoxlaması
        if (url.includes('youtube.com') || url.includes('youtu.be')) {
            data = await extractYouTubeData(url);
            isVideo = true;
            success = data.thumbnail !== null;
        } 
        
        // 2. TikTok yoxlaması
        else if (url.includes('tiktok.com/')) {
            data = await extractTikTokData(url);
            isVideo = true;
            success = data?.thumbnail !== null; // data null ola bilər
        } 
        
        // 3. Ümumi Oembed yoxlaması (Vimeo və başqaları üçün)
        if (!success || !data.embedHtml) { 
            const oembedResult = await extractOembedData(url);
            if (oembedResult) {
                // Əvvəlki məlumatlar üzərinə yazılır (xüsusən generic data varsa)
                data = { ...data, ...oembedResult };
                success = data.thumbnail !== null;
                if (data.duration && data.duration !== 'N/A') isVideo = true; 
            }
        }

        // 4. Generic Puppeteer yoxlaması (Ən son ehtiyat)
        if (!success) {
            data = { ...data, ...(await extractGenericData(url)) };
            success = data.thumbnail !== null && data.thumbnail !== 'https://via.placeholder.com/640x360?text=Error+Loading+Page';
        }
        
        // Şəkilin ölçüsünü tapırıq
        const size = await getImageSize(data.thumbnail);

        // Bütün məlumatları birləşdirib cavab qaytarırıq
        console.log('🖼️ Çıxış Məlumatı:', { ...data, size });
        res.json({
            name: data.title || 'Başlıq tapılmadı',
            description: data.description || 'Təsvir tapılmadı',
            date: data.date || 'Tarix tapılmadı',
            duration: data.duration || 'N/A', // Formatlanmış müddət (HH:MM:SS)
            size_mb: size, // Fayl ölçüsü (MB)
            thumbnail_url: data.thumbnail || 'https://via.placeholder.com/640x360?text=Xəta', // Şəkilin linki
            embed_html: data.embedHtml || null, // Embed HTML
            is_video: isVideo
        });

    } catch (error) {
        // Konsol xətası Azərbaycan dilindədir
        console.error('❌ Ümumi API Xətası:', error.message);
        res.status(500).json({ 
            name: null, 
            description: null,
            date: null,
            duration: null,
            size_mb: null,
            thumbnail_url: null,
            embed_html: null,
            error: 'Daxili Server Xətası' // Cavab məzmunu Azərbaycan dilindədir
        });
    }
});

// Əsas səhifə yönləndirilməsi (əgər `public/index.html` mövcuddursa)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html')); 
});

// ✅ SERVERİN BAŞLANMASI YALNIZ BURADADIR
app.listen(PORT, () => {
    console.log(`✅ Server hazırdır: http://localhost:${PORT}`);
});
